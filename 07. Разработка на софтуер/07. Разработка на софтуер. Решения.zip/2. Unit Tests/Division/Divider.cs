﻿namespace Division
{
    public class Divider
    {
        public int Divide(int x, int y)
        {
            if (y != 0)
            {
                return x / y;
            }
            return 0;
        }
    }
}
