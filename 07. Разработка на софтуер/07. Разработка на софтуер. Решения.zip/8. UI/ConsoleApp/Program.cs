﻿using System;
using ConsoleApp.Presentation;

namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Display display = new Display();
        }
    }
}