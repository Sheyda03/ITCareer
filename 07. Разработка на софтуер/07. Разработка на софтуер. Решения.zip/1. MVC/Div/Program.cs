﻿using Div.Controllers;

namespace Div
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var controller = new Controller();
        }
    }
}