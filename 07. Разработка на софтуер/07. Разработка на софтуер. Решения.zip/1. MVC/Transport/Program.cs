﻿using Transport.Controllers;

namespace Transport
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var controller = new Controller();
        }
    }
}