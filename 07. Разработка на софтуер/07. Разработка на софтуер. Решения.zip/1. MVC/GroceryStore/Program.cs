﻿using GroceryStore.Controllers;

namespace GroceryStore
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var controller = new Controller();
        }
    }
}