﻿using Repair.Controllers;

namespace Repair
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var controller = new Controller();
        }
    }
}