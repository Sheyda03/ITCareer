﻿using Histogram.Controllers;

namespace Histogram
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var controller = new Controller();
        }
    }
}