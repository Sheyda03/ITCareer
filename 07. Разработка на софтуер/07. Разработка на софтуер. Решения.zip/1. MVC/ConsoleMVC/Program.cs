﻿using ConsoleMVC.Controller;

namespace ConsoleMVC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TipCalculatorController controller = new TipCalculatorController();
        }
    }
}