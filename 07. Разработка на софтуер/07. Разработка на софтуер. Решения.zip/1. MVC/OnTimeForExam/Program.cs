﻿using OnTimeForExam.Controllers;

namespace OnTimeForExam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var controller = new Controller();
        }
    }
}