﻿using CrudWithoutOrm.Presentation;

/// <summary>
/// Task "CRUD without ORM" namespace.
/// </summary>
namespace CrudWithoutOrm
{
    /// <summary>
    /// Task "CRUD without ORM" main program class.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Task "CRUD without ORM" main program method.
        /// </summary>
        public static void Main(string[] args)
        {
            Display display = new Display();
        }
    }
}