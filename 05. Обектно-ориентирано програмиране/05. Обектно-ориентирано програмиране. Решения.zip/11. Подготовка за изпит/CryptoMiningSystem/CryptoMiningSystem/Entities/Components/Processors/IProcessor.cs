namespace CryptoMiningSystem.Entities.Components.Processors.Contracts
{
    public interface IProcessor
    {
        int MineMultiplier { get; }
    }
}