﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CryptoMiningSystem.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}