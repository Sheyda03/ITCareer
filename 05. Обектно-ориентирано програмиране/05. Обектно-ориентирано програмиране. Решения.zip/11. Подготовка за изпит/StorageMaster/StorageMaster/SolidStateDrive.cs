﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.Products
{
    class SolidStateDrive : Product
    {
        public SolidStateDrive(double price) : base(price, 0.1)
        {

        }
    }
}
