﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.Entities.Vehicles
{
    class Truck : Vehicle
    {
        public Truck() : base(5)
        {

        }
    }
}
