# ViceCity
SoftUni Judje C# OOP Exam (11 August 2019)
https://judge.softuni.bg/Contests/1777/CSharp-OOP-Exam-11-August-2019