﻿namespace MultipleInheritance
{
    public class Puppy : Dog
    {
        public void Weep()
        {
            Console.WriteLine("Weeping...");
        }
    }
}
