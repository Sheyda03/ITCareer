﻿namespace AnimalKingdom
{
    interface IMakeNoise
    {
        void MakeNoise();
    }
}
