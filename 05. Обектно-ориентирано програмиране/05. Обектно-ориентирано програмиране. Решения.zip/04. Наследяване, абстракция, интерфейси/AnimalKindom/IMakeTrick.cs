﻿namespace AnimalKingdom
{
    interface IMakeTrick
    {
        void MakeTrick();
    }
}
