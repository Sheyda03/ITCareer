﻿namespace FoodShortages
{
    interface IBuyer
    {
        void BuyFood();
        int Food {get; set;}
    }
}
