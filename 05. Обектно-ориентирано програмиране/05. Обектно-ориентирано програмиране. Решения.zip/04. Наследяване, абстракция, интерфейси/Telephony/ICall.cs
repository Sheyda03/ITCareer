﻿namespace Telephony
{
    interface ICall
    {
        void Call(string[] numbers);
    }
}