﻿namespace Telephony
{
    interface IBrowse
    {
        void Browse(string[] sites);
    }
}