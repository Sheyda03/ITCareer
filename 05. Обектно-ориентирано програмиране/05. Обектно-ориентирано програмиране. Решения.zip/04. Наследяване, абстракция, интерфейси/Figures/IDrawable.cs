﻿namespace Figures
{
    public interface IDrawable
    {
        public void Draw();
    }
}