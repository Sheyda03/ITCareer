﻿namespace BorderControl
{
    class Robot : Data
    {
        public Robot(string id, string name) : base(id, name)
        {
            // nope
        }
    }
}
