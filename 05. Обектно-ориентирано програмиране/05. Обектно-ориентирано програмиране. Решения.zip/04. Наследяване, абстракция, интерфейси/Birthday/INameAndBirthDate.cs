﻿namespace Birthday
{
    interface INameAndBirthDate
    {
        string Name { get; }
        string BirthDate { get; }
    }
}
