﻿namespace Birthday
{
    class Robot : Data
    {
        public Robot(string id,string name) : base(id, name)
        {
            //nope
        }
    }
}
