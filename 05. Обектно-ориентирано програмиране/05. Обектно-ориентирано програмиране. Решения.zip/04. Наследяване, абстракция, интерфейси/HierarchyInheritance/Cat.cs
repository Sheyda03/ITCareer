﻿namespace HierarchyInheritance
{
    public class Cat : Animal
    {
        public void Meow()
        {
            Console.WriteLine("Meowing...");
        }
    }
}
