﻿namespace FakeAxeAndDummy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Empty
        }
    }
}