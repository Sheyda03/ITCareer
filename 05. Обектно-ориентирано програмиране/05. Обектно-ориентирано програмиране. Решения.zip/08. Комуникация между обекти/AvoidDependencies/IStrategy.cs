﻿namespace AvoidDependencies
{
    interface IStrategy
    {
        int Calculate(int first, int second);
    }
}
