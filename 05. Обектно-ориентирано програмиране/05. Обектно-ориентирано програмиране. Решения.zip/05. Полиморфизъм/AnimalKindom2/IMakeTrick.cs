﻿namespace AnimalKindom2
{
    public interface IMakeTrick
    {
        string MakeTrick();
    }
}