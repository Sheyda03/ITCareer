﻿namespace AnimalKindom2
{
    public interface IMakeNoise
    {
        string MakeNoise();
    }
}