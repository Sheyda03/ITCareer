﻿namespace AnimalFarm
{
    public abstract class Felime : Mammal
    {
        public Felime(string animalType, string name, double weight, string livingRegion) : base(animalType, name, weight, livingRegion)
        {
            // nope
        }
    }
}