﻿namespace BarracksWars
{
    public interface IUnit : IDestroyable, IAttacker
    {
        // nope
    }
}