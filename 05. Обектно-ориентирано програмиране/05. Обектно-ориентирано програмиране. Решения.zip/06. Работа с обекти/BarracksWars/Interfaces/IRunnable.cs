﻿namespace BarracksWars
{
    public interface IRunnable
    {
        void Run();
    }
}