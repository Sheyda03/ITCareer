﻿namespace BarracksWars
{
    public interface IExecutable
    {
        string Execute();
    }
}