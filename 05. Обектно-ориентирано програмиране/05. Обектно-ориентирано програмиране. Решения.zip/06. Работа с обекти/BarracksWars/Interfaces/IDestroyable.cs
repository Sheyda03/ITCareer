﻿namespace BarracksWars
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}