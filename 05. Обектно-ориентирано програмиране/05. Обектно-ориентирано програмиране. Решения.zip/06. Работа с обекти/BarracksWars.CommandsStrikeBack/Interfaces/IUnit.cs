﻿namespace BarracksWars.CommandsStrikeBack
{
    public interface IUnit : IDestroyable, IAttacker
    {
        // nope
    }
}