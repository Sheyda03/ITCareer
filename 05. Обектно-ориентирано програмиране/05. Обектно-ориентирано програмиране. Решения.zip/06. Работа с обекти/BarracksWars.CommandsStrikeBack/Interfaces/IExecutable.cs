﻿namespace BarracksWars.CommandsStrikeBack
{
    public interface IExecutable
    {
        string Execute();
    }
}