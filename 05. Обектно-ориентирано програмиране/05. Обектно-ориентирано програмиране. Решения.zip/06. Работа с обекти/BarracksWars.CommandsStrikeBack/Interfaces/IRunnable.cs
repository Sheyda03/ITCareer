﻿namespace BarracksWars.CommandsStrikeBack
{
    public interface IRunnable
    {
        void Run();
    }
}