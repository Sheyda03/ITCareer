﻿namespace BarracksWars.CommandsStrikeBack
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}